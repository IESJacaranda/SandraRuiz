package interf.ejemplo;

public interface IInstalacionDeportiva {
	
	
	public double superficieJuego();
	
	public int aforoMaximoPublico();
	
	public String actividadesOfrecidas();
}
