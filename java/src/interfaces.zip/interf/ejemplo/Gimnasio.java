package interf.ejemplo;

public class Gimnasio extends Polideportivo {

}
