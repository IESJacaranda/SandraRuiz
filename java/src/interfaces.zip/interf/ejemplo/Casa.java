package interf.ejemplo;

public class Casa implements IEdificio {

	public int numeroDeHabitaciones() {
		return 7;
	}
	
	@Override
	public double getSuperficieTotal() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getNumeroPlantas() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int aforoMaximo() {
		// TODO Auto-generated method stub
		return 0;
	}

}
