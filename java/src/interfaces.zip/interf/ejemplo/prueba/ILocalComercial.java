package interf.ejemplo.prueba;

public interface ILocalComercial extends IEdificio {

	public static final double PRECIO_METRO_LOCAL_COMERCIAL = 3000;
	
	public String actividadComercial();
}
