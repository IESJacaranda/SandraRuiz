package interf.ejemplo.prueba;

public interface IEdificio {

	public final static double PRECIO_POR_METRO = 1500;
	
	public double getSuperficieEdificio();
	
	public double getPrecioEdificio();
	
	
}
