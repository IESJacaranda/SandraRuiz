package interf.ejemplo;

public interface IEdificio {

	
	public double getSuperficieTotal();
	
	public int getNumeroPlantas();
	
	public int aforoMaximo();
	
	
}
